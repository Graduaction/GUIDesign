﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GUI.UI
{
    public partial class Form38 : Form
    {
        public Form38()
        {
            InitializeComponent();
        }
    }
}
